<!--
The user will see this page after he has paid.
-->

<!DOCTYPE html>
<html>
<head>
    <title>My demo website</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h1>Thank you!</h1>
    <p>Your payment will be processed by the system</p>
</div>
</body>
</html>