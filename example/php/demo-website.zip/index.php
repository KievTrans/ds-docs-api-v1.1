<?php
error_reporting(E_ERROR | E_PARSE);

// If the user has clicked the "Pay" button
if (isset($_POST['pay']))
{
    // Define the file to save transactions
    $dbFile = 'data.json';

    // Set API URL
    $apiUrl = 'https://api.dshield.co/v1.1/payment';

    // Set API key
    $apiKey = 'YOUR_API_KEY_HERE';

    // Prepare data
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $amount = $_POST['amount'];
    $currency = $_POST['currency'];
    $clientId = rand(1,999999); // the user ID is random for the demo
    $email = 'example@mail.com'; // the user email

    $data = array(
        'client_id'             => $clientId,
        'client_email'          => $email,
        'client_private_name'   => $firstName,
        'client_family_name'    => $lastName,
        'amount'                => $amount,
        'currency'              => $currency,
        'description'           => 'Short description of the transaction',
        'success_url'           => 'https://' . $_SERVER['HTTP_HOST'] . '/thank.php',
        'failed_url'            => 'https://' . $_SERVER['HTTP_HOST'] . '/error.php',
        'callback_url'          => 'https://' . $_SERVER['HTTP_HOST'] . '/callback.php'
    );

    // Set up the CURL
    $curl = curl_init();

    curl_setopt_array($curl,
        array(
            CURLOPT_URL             => $apiUrl,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_TIMEOUT         => 0,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST   => 'POST',
            CURLOPT_POSTFIELDS      => $data,                  // set the data in the body
            CURLOPT_HTTPHEADER      => ["api-key: $apiKey"]    // set the API key in the header
        )
    );

    // Send the request
    $response = curl_exec($curl);

    // Close the connection
    curl_close($curl);

    // Parse the response
    $response = json_decode($response, true);

    // If the response doesn't contain the data we need, show the error
    if (!isset($response['data']) || !isset($response['data']['id']) || !isset($response['data']['payment_url']))
    {
        header('Content-Type: application/json');
        die(json_encode($response, JSON_PRETTY_PRINT));
    }

    // Prepare the data about the transaction to save
    $info = [
        'id'            => $response['data']['id'],             // transaction ID
        'payment_url'   => $response['data']['payment_url'],    // payment URL you give to the user
        'client_id'     => $clientId,
        'client_email'  => $email,
        'amount'        => $amount,
        'currency'      => $currency,
        'status'        => 'pending',
        'created_at'    => date('c')
    ];

    // Get the data of all the transactions from the database file
    $data = file_get_contents($dbFile);

    // Add the new transaction to the array
    $dataArray = json_decode($data, true);

    // Add the current transaction to the array
    $dataArray[] = $info;

    // Encode the array to JSON and save it to the file
    $dataJson = json_encode($dataArray, JSON_PRETTY_PRINT);
    file_put_contents($dbFile, $dataJson, LOCK_EX);

    // Redirect the user to the payment page
    header('Location: ' . $response['data']['payment_url']);

    // Comment the line above and uncomment this lines to see the response from the API in the browser
    // header('Content-Type: application/json');
    // die(json_encode($response, JSON_PRETTY_PRINT));
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My demo website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="container">
    <h1>Customer Name</h1>

    <p>Pay now with credit card</p>

    <form action="#" method="post">

        <input type="text" id="first_name" name="first_name" placeholder="First Name">
        <br/>
        <input type="text" id="last_name" name="last_name" placeholder="Last Name">

        <div class="amount">
            <input type="number" step="any" id="amount" name="amount" placeholder="Amount">
            <select id="currency" name="currency">
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="GBP">GBP</option>
            </select>
        </div>

        <input id="pay" type="submit" name="pay" value="Pay">
    </form>

    <br>
    <p>Min $10 - Max $900</p>
    <p>Need more? Contact us <a href="mailto:admin@dshield.co">admin@dshield.co</a></p>

</div>
</body>
</html>